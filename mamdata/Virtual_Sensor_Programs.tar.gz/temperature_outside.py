# LM35 25°C to 30°C
import os
import time
import numpy
from random import*
while True:
    folder_name = time.strftime("%Y-%m-%d")
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    os.chdir(folder_name)
    while folder_name == time.strftime("%Y-%m-%d"):
        name1 = time.strftime("%Y-%m-%d_%H")
        if not os.path.exists(name1):
            os.makedirs(name1)
        os.chdir(name1)
        name2 = "temperature_outside.csv"
        while name1 == time.strftime("%Y-%m-%d_%H"):
            f = open(name2,'a')
            a = numpy.random.choice(numpy.arange(1,3), p=[0.1,0.9])
            if (a == 2):
                temperature_outside = uniform(154,163)#153.45=25,163.68=30
            else:
                temperature_outside = uniform(0,1024)                    
            f.write('%.2f'%(temperature_outside))
            f.write('\n')
            time.sleep(1)
            f.close()
        else:
            os.chdir('..')
    else:
        os.chdir('..')

